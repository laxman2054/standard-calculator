from django.apps import AppConfig


class htAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "ht_app"
